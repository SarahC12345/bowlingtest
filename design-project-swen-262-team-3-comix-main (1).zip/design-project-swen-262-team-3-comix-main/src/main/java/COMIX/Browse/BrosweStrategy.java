package COMIX.Browse;

import java.util.List;

import COMIX.ComicGrader.Comic;

public interface BrosweStrategy {
    public void doBrowse(List<Comic> personalDatabase);
}
