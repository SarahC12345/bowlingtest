package COMIX.DatabaseModifier;
public interface SlabbComic extends CommandInvoker{
    public void execute();
}