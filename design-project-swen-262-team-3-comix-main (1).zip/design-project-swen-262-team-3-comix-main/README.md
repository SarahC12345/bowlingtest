# SWEN-262 Design Project Starter Repo

## This is a group project

Name: Morin 

Name: Ayden

Name: Afia

Name: Xander

Name: Sarah 
